import React, { Component } from 'react'

export class TechnologyPage extends Component {
  render() {
    return (
      <div>TechnologyPage</div>
    )
  }
}

export default TechnologyPage