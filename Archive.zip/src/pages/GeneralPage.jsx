import React, { Component } from 'react'

export class GeneralPage extends Component {
  render() {
    return (
      <div>GeneralPage</div>
    )
  }
}

export default GeneralPage