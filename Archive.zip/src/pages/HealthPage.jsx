import React, { Component } from 'react'

export class HealthPage extends Component {
  render() {
    return (
      <div>HealthPage</div>
    )
  }
}

export default HealthPage