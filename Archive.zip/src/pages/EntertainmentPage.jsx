import React, { Component } from 'react'

export class EntertainmentPage extends Component {
  render() {
    return (
      <div>EntertainmentPage</div>
    )
  }
}

export default EntertainmentPage