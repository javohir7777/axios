import React, { Component } from 'react'

export class SciencePage extends Component {
  render() {
    return (
      <div>SciencePage</div>
    )
  }
}

export default SciencePage