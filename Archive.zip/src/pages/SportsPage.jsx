import React, { Component } from 'react'

export class SportsPage extends Component {
  render() {
    return (
      <div>SportsPage</div>
    )
  }
}

export default SportsPage